<?php
// created: 2016-11-09 19:33:33
$dictionary["RT_Employees"]["fields"]["rt_increment_histroy_rt_employees"] = array (
  'name' => 'rt_increment_histroy_rt_employees',
  'type' => 'link',
  'relationship' => 'rt_increment_histroy_rt_employees',
  'source' => 'non-db',
  'module' => 'RT_Increment_Histroy',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_RT_INCREMENT_HISTROY_RT_EMPLOYEES_FROM_RT_INCREMENT_HISTROY_TITLE',
);
