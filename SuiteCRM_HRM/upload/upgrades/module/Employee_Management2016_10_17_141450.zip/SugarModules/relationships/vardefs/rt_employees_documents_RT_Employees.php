<?php
// created: 2016-10-17 14:14:50
$dictionary["RT_Employees"]["fields"]["rt_employees_documents"] = array (
  'name' => 'rt_employees_documents',
  'type' => 'link',
  'relationship' => 'rt_employees_documents',
  'source' => 'non-db',
  'module' => 'Documents',
  'bean_name' => 'Document',
  'side' => 'right',
  'vname' => 'LBL_RT_EMPLOYEES_DOCUMENTS_FROM_DOCUMENTS_TITLE',
);
