<?php
// created: 2016-10-17 14:14:50
$dictionary["Document"]["fields"]["rt_employees_documents"] = array (
  'name' => 'rt_employees_documents',
  'type' => 'link',
  'relationship' => 'rt_employees_documents',
  'source' => 'non-db',
  'module' => 'RT_Employees',
  'bean_name' => false,
  'vname' => 'LBL_RT_EMPLOYEES_DOCUMENTS_FROM_RT_EMPLOYEES_TITLE',
  'id_name' => 'rt_employees_documentsrt_employees_ida',
);
$dictionary["Document"]["fields"]["rt_employees_documents_name"] = array (
  'name' => 'rt_employees_documents_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_RT_EMPLOYEES_DOCUMENTS_FROM_RT_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'rt_employees_documentsrt_employees_ida',
  'link' => 'rt_employees_documents',
  'table' => 'rt_employees',
  'module' => 'RT_Employees',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
$dictionary["Document"]["fields"]["rt_employees_documentsrt_employees_ida"] = array (
  'name' => 'rt_employees_documentsrt_employees_ida',
  'type' => 'link',
  'relationship' => 'rt_employees_documents',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_RT_EMPLOYEES_DOCUMENTS_FROM_DOCUMENTS_TITLE',
);
