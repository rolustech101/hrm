<?php
// created: 2016-10-17 14:14:49
$dictionary["RT_Employees"]["fields"]["rt_employees_rt_payroll"] = array (
  'name' => 'rt_employees_rt_payroll',
  'type' => 'link',
  'relationship' => 'rt_employees_rt_payroll',
  'source' => 'non-db',
  'module' => 'RT_Payroll',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_RT_EMPLOYEES_RT_PAYROLL_FROM_RT_PAYROLL_TITLE',
);
