<?php
// created: 2016-10-17 14:14:49
$dictionary["RT_Employees"]["fields"]["rt_employees_rt_bonus"] = array (
  'name' => 'rt_employees_rt_bonus',
  'type' => 'link',
  'relationship' => 'rt_employees_rt_bonus',
  'source' => 'non-db',
  'module' => 'RT_Bonus',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_RT_EMPLOYEES_RT_BONUS_FROM_RT_BONUS_TITLE',
);
