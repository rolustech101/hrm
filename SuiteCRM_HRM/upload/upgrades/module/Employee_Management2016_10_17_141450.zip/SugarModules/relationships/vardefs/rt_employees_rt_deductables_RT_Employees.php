<?php
// created: 2016-10-17 14:14:50
$dictionary["RT_Employees"]["fields"]["rt_employees_rt_deductables"] = array (
  'name' => 'rt_employees_rt_deductables',
  'type' => 'link',
  'relationship' => 'rt_employees_rt_deductables',
  'source' => 'non-db',
  'module' => 'RT_Deductables',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_RT_EMPLOYEES_RT_DEDUCTABLES_FROM_RT_DEDUCTABLES_TITLE',
);
