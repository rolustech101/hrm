<?php
// created: 2016-10-17 14:14:49
$dictionary["RT_Employees"]["fields"]["rt_employees_rt_leaves"] = array (
  'name' => 'rt_employees_rt_leaves',
  'type' => 'link',
  'relationship' => 'rt_employees_rt_leaves',
  'source' => 'non-db',
  'module' => 'RT_Leaves',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_RT_EMPLOYEES_RT_LEAVES_FROM_RT_LEAVES_TITLE',
);
