<?php
// created: 2016-10-17 14:14:49
$dictionary["RT_Employees"]["fields"]["rt_employees_rt_increment_history"] = array (
  'name' => 'rt_employees_rt_increment_history',
  'type' => 'link',
  'relationship' => 'rt_employees_rt_increment_history',
  'source' => 'non-db',
  'module' => 'RT_Increment_History',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_RT_EMPLOYEES_RT_INCREMENT_HISTORY_FROM_RT_INCREMENT_HISTORY_TITLE',
);
