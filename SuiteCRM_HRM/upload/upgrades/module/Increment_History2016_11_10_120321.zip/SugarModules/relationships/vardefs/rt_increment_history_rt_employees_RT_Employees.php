<?php
// created: 2016-11-10 12:03:21
$dictionary["RT_Employees"]["fields"]["rt_increment_history_rt_employees"] = array (
  'name' => 'rt_increment_history_rt_employees',
  'type' => 'link',
  'relationship' => 'rt_increment_history_rt_employees',
  'source' => 'non-db',
  'module' => 'RT_Increment_History',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_RT_INCREMENT_HISTORY_RT_EMPLOYEES_FROM_RT_INCREMENT_HISTORY_TITLE',
);
