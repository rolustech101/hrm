<?php
// created: 2016-11-09 19:01:06
$dictionary["RT_Employees"]["fields"]["rt_bonus_rt_employees"] = array (
  'name' => 'rt_bonus_rt_employees',
  'type' => 'link',
  'relationship' => 'rt_bonus_rt_employees',
  'source' => 'non-db',
  'module' => 'RT_Bonus',
  'bean_name' => 'RT_Bonus',
  'side' => 'right',
  'vname' => 'LBL_RT_BONUS_RT_EMPLOYEES_FROM_RT_BONUS_TITLE',
);
